import { Button, FormControl, Input } from "@material-ui/core";
import React, { useEffect, useState } from "react";
import { useLocation } from "react-router";
import { Link, withRouter } from "react-router-dom";
import axios from "axios";
import "./App.css";

const Edit = () => {
  const [data, setData] = useState({});
  const [name, setName] = useState("");
  let id = useLocation().pathname;
  id = id.substr(1);

  const dataUrl = `http://localhost:5000/properties/${id}`;
  const getData = () => {
    fetch(dataUrl)
      .then((res) => res.json())
      .then((json) => {
        setData(json);
      });
  };

  const handleSubmit = () => {
    axios.put(dataUrl, data);
  };
  const handleDelete = () => {
    axios.delete(dataUrl);
  };

  const handleChange = (name) => (event) => {
    setData({ ...data, [name]: event.target.value });
  };

  useEffect(() => {
    getData();
  }, []);
  return (
    <div className="App">
      <h2>Edit Page</h2>
      <form noValidate>
        <FormControl>
          <Input
            id="key"
            value={data.id}
            placeholder="Id"
            style={{ margin: "1rem" }}
            onChange={handleChange("id")}
          />
        </FormControl>
        <br />
        <FormControl>
          <Input
            id="name"
            placeholder="Name"
            style={{ margin: "1rem" }}
            value={data.name}
            onChange={handleChange("name")}
          />
        </FormControl>
        <br />
        <FormControl>
          <Input
            id="isrented"
            placeholder="IsRented"
            style={{ margin: "1rem" }}
            value={data.isRented}
            onChange={handleChange("isRented")}
          />
        </FormControl>
        <br />
        <FormControl>
          <Input
            id="condition"
            placeholder="Condition"
            style={{ margin: "1rem" }}
            value={data.condition}
            onChange={handleChange("condition")}
          />
        </FormControl>
        <br />
        <FormControl>
          <Input
            id="tenants"
            placeholder="Tenants"
            style={{ margin: "1rem" }}
            value={data.tenants}
            onChange={handleChange("tenants")}
          />
        </FormControl>
      </form>
      <Button variant="contained" color="primary" onClick={handleSubmit}>
        Submit
      </Button>
      <Button variant="contained" color="secondary" onClick={handleDelete}>
        Delete
      </Button>
      <Link to="/">
        <Button variant="outlined" color="secondary">
          Cancel
        </Button>
      </Link>
    </div>
  );
};

export default withRouter(Edit);
