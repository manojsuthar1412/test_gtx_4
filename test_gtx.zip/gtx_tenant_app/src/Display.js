import React from "react";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Paper from "@material-ui/core/Paper";
import { Link, withRouter } from "react-router-dom";
import { Button } from "@material-ui/core";

const Display = ({ rows }) => {
  return (
    <TableContainer component={Paper}>
      <Table aria-label="simple table">
        <TableHead>
          <TableRow>
            <TableCell>Name</TableCell>
            <TableCell align="right">Id</TableCell>
            <TableCell align="right">IsRented</TableCell>
            <TableCell align="right">Condition</TableCell>
            <TableCell align="left">Tenants</TableCell>
            <TableCell align="center">Actions</TableCell>
            <TableCell align="right">
              <Link to="/create">
                <Button variant="contained" color="priamry">
                  Create
                </Button>
              </Link>
            </TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.map((row) => (
            <TableRow key={row.id}>
              <TableCell component="th" scope="row">
                {row.name}
              </TableCell>
              <TableCell align="right">{row.id}</TableCell>
              <TableCell align="right">{row.isRented}</TableCell>
              <TableCell align="right">{row.condition}</TableCell>
              <TableCell align="left">{row.tenants}</TableCell>
              <TableCell align="center">
                <Link to={`/${row.id}`}>
                  <Button variant="contained" color="primary">
                    Edit
                  </Button>
                </Link>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
};

export default withRouter(Display);
