import { useEffect, useState } from "react";
import "./App.css";
import Display from "./Display";
// import restProvider from "ra-data-simple-rest";

function App() {
  const [properties, setProperties] = useState([]);
  const dataUrl = "http://localhost:5000/properties";
  const getData = async () => {
    await fetch(dataUrl)
      .then((response) => response.json())
      .then((json) => {
        // console.log("PROP: ", json);
        setProperties((old) => [...old, json]);
      });
    // printData();
  };

  useEffect(async () => {
    await getData();
  }, []);

  const printData = () => {
    return (
      <div>
        <Display rows={properties[0]} />
      </div>
    );
  };
  // data.then((res) => {
  //   // console.log(res);
  //   setProperties(res);
  // });
  return (
    <div className="App">
      <h2>All Properties</h2>
      {properties.length !== 0 && printData()}
    </div>
  );
}

export default App;
